<template>
  <div>Not Found</div>
</template>

<script>
export default {};
</script>

<style></style>
